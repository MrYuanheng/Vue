<?php
header('Content-type:text/html;charset=utf-8');
$id=new PDO("mysql:host=localhost;name=my",'root','340918')or die("数据库链接失败");
$id->query("set names utf8");
$id->query("use tab");
$u_name=$_POST["name"];
$u_anename=$_POST["anename"];
$u_towname=$_POST["towname"];
$u_srename=$_POST["srename"];
$sql = "insert into niba (name,anename,towname,srename) VALUES ('".$_POST['u_name']."','".$_POST['u_anename']."','".$_POST['u_towname']."','".$_POST['u_srename']."')";
$result = $id->query($sql) or die("失败");
if($result) {
    echo "成功";
    echo "<a href='index_one.php'>导出</a>";
}
?>