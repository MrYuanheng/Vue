 <?php
header('Content-type:text/html;charset=utf-8');
$_host="localhost:3306";
$user="root";
$pass="340918";
$id=mysql_connect($host,$user,$pass);
mysql_select_db("tab")or die ("数据库链接失败");
$sql="select * from niba ";
mysql_query("set names 'utf8'");
$result=mysql_query($sql,$id);
while($row=mysql_fetch_array($result)) {
?>
    <?php echo $row['id'] ?>
    <?php echo $row['name'] ?>
    <?php echo $row['anename'] ?>
    <?php echo $row['towname'] ?>
    <?php echo $row['srename'] ?>
    <?php echo "<br/>"?>
<?php
}
?>