<?php
$db_host ='localhost:3306'; 
$db_user ='root';      
$db_pass ='340918';        
$db_name ='tab';    
?>
