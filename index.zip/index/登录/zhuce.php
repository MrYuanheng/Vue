<?php
 if ($_POST['name'])
  {
       $host = "localhost:3306";
       $user = "root";
       $pass = "340918";
       $dbname = "tab";
       $id = mysql_connect($host,$user,$pass);
       mysql_select_db($dbname);
      
       $sql ="insert into user(name,password,sex,age) values ('" . $_POST['name'] . "', '" . $_POST['password'] . "', '" . $_POST['sex'] . "', '" . $_POST['age'] . "')";
        mysql_query("set names utf8");
 if($result =mysql_query($sql))
 {

       echo "用户：" . $_POST['name'] . "已添加。";
       echo "<a href=index.php>返回</a>"; 
     }
 }
      else {
?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="c.css">
    <script src=""></script>
    <title>用户注册</title>
  </head>
  <body>
    <div id="a1">   
     <h1>用户注册</h1>
       <form name="form" action="zhuce.php" method="post">
	 <tr><td>姓名</td><td><input type="text" name="name" size="30" required="required"></td></tr><br />
	 <tr><td>密码</td><td><input type="text" name="password" size="30" required="required"></td></tr><br />
         <tr><td>性别</td><td><input type="text" name="sex" size="30" required="required"></td></tr><br />
         <tr><td>年龄</td><td><input type="text" name="age" size="30" required="required"></td></tr><br />
         <tr><td colspan="2" align="center"><input type="submit" name="ok" value="提交"></td></tr>
       </form>
   </div>
  </body>
</html>
<?php
   }
?>
