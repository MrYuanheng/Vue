<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>
<form action="upload_file.php" method="post" enctype="multipart/form-data">
      <label for="file">Filename:</label>
      <input type="file" name="file" id="file" /> 
      <br />
      <input type="submit" name="submit" value="提交" />
    </form>
    <?php
$host = "localhost";
$host_name = "root";
$host_pwd = "340918";
$con = mysql_connect($host,$host_name,$host_pwd)or die(mysql_error());
$db = mysql_select_db("tab", $con);
$result = mysql_query("SELECT * FROM imag");
while($row = mysql_fetch_assoc($result))
{
  echo "id:".$row['id'];
  echo "<img src=".$row['path'].$row['name']." style='width:150px; height:20    0px'><br/>";
}
?>
</body>
</html>