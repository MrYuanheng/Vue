<?php
$host = "localhost";
$host_name = "root";
$host_pwd = "340918";
$con = mysql_connect($host,$host_name,$host_pwd)or die(mysql_error());
$db = mysql_select_db("tab", $con);
if (!$db){
	mysql_query("CREATE DATABASE tab",$con);
};
$table = "imag";
if(!@mysql_num_rows(mysql_query("SHOW TABLES LIKE '". $table."'")==1)){
	$sql = "CREATE TABLE imag(id int NOT NULL AUTO_INCREMENT PRIMARY KEY,name varchar(15),path varchar(255))";
	mysql_query($sql,$con);
};
if ((($_FILES["file"]["type"] == "image/gif")|| ($_FILES["file"]["type"] == "image/jpeg")|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 20000000))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    	$name = $_FILES["file"]["name"];
    	$path = "images/";
    if (file_exists("images/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " 上传成功. ";
     echo "<a href='img.php'>导出</a>";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "images/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "images/" . $_FILES["file"]["name"];
      }
      $sql="INSERT INTO imag (name, path) VALUES ('$name','$path')";
      if (!mysql_query($sql,$con)){
      	die('Error: ' . mysql_error());
      }
    }
    $result = mysql_query("SELECT * FROM images");
    while($row = mysql_fetch_array($result))
    {
    	foreach ($row as $k=>$v){
    		echo "<tr>";
    	}
    	
    }
    
    
  }

?>












